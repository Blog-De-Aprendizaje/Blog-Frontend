// src/hooks/useComment.js
import { useState, useEffect } from 'react';
import axios from 'axios';

export const useComment = (postId) => {
  const [comment, setComment] = useState(null); // Inicialmente no hay comentario
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchComment = async () => {
      try {
        // Realizamos la solicitud a la API
        const response = await axios.get(`http://127.0.0.1:3000/blogAprendizaje/v1/comments/getLatestComment/${postId}`);

        // Verificamos si la respuesta tiene datos y si el campo 'comment' está presente
        if (response && response.data && response.data.comment) {
          setComment(response.data.comment); // Si existe el comentario, lo almacenamos
        } else {
          setComment(null); // Si no hay comentario, seteamos null
        }
      } catch (err) {
        setError('Aún no hay comentarios'); // Si ocurre un error, lo mostramos
      } finally {
        setLoading(false); // Terminamos la carga
      }
    };

    if (postId) {
      fetchComment(); // Solo llamamos a la API si hay un postId
    } else {
      setLoading(false); // Si no hay postId, terminamos la carga
    }
  }, [postId]); // El hook depende de postId, se ejecutará cuando cambie

  return { comment, loading, error };
};
