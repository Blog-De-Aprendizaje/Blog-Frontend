import React, { useState, useEffect } from "react";
import { usePosts } from "../hooks/usePosts";
import { Comment } from './LatestComment'; // Asegúrate de importar el componente de comentarios
import { Link } from 'react-router-dom'; // Importar Link para la navegación
import '../styles/GetPost.css'; // Asegúrate de tener el CSS para los posts
import filtroIcon from '../assets/filtro.png'; // Importamos la imagen

export const GetPost = () => {
  const { posts, error, loading } = usePosts();
  const [filter, setFilter] = useState('');
  const [filteredPosts, setFilteredPosts] = useState(posts);
  const [filterMenuVisible, setFilterMenuVisible] = useState(false); // Estado para mostrar/ocultar el menú de filtros
  const [selectedCourse, setSelectedCourse] = useState(''); // Estado para seleccionar curso
  const [selectedDate, setSelectedDate] = useState(''); // Estado para seleccionar fecha
  const [availableCourses, setAvailableCourses] = useState([]); // Lista de cursos disponibles

  useEffect(() => {
    // Extraer los cursos únicos de las publicaciones
    const courses = [...new Set(posts.map(post => post.course))]; // Obtener los cursos únicos
    setAvailableCourses(courses); // Guardamos los cursos disponibles
    setFilteredPosts(posts); // Aseguramos que las publicaciones filtradas sean todas al principio
  }, [posts]); // Este efecto se ejecuta cuando `posts` cambia

  // Cambiar el filtro
  const handleFilterChange = (filterType, value) => {
    if (filterType === 'course') {
      setSelectedCourse(value);
    } else if (filterType === 'date') {
      setSelectedDate(value);
    }
  };

  // Función para filtrar publicaciones
  useEffect(() => {
    let filtered = posts;

    // Filtrar por curso, si se seleccionó un curso
    if (selectedCourse) {
      filtered = filtered.filter(post => post.course === selectedCourse);
    }

    // Filtrar por fecha, si se seleccionó una opción de fecha
    if (selectedDate === 'newest') {
      filtered = [...filtered].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); // Filtrar por fecha (más reciente)
    } else if (selectedDate === 'oldest') {
      filtered = [...filtered].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)); // Filtrar por fecha (más antiguo)
    }

    // Actualizamos el estado de las publicaciones filtradas
    setFilteredPosts(filtered);
  }, [posts, selectedCourse, selectedDate]); // Este efecto se ejecuta cuando `selectedCourse` o `selectedDate` cambian

  // Si estamos cargando o si hay un error
  if (loading) return <p className="loading">Cargando publicaciones...</p>;
  if (error) return <p className="error">Error: {error}</p>;

  return (
    <div className="post-list">
      <h1>Publicaciones</h1>

      {/* Botón de filtro flotante */}
      <button className="filter-button" onClick={() => setFilterMenuVisible(!filterMenuVisible)}>
        <img src={filtroIcon} alt="Filtro" />
      </button>

      {/* Menú de filtros */}
      {filterMenuVisible && (
        <div className="filter-menu">
          <h2>Filtrar por:</h2>

          {/* Filtro por curso */}
          <div className="filter-option">
            <label htmlFor="course">Curso</label>
            <select 
              id="course" 
              value={selectedCourse} 
              onChange={(e) => handleFilterChange('course', e.target.value)}
            >
              <option value="">Selecciona un curso</option>
              {availableCourses.map((course, index) => (
                <option key={index} value={course}>
                  {course}
                </option>
              ))}
            </select>
          </div>

          {/* Filtro por fecha */}
          <div className="filter-option">
            <label htmlFor="date">Fecha</label>
            <select 
              id="date" 
              value={selectedDate} 
              onChange={(e) => handleFilterChange('date', e.target.value)}
            >
              <option value="">Selecciona una fecha</option>
              <option value="newest">Más reciente</option>
              <option value="oldest">Más antiguo</option>
            </select>
          </div>

          {/* Botón para quitar filtro */}
          <button onClick={() => { setSelectedCourse(''); setSelectedDate(''); }}>Quitar Filtro</button>
        </div>
      )}

      {/* Mostrar las publicaciones filtradas */}
      {filteredPosts.length === 0 ? (
        <p>No hay publicaciones para mostrar.</p>
      ) : (
        filteredPosts.map((post) => (
          <div key={post._id} className="post">
            <h2>{post.title}</h2>
            <p><strong>Curso:</strong> {post.course}</p>
            <p>{post.content}</p>
            <p><em>Publicado el {new Date(post.createdAt).toLocaleDateString()}</em></p>

            {/* Botón para ver detalles de la publicación */}
            <Link to={`/post/${post._id}`}>
              <button>Ver Publicación</button>
            </Link>

            {/* Mostrar el comentario más reciente debajo de la publicación */}
            <Comment postId={post._id} />
          </div>
        ))
      )}
    </div>
  );
};
