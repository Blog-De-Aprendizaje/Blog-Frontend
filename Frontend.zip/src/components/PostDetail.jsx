// src/components/PostDetail.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { AddComment } from './AddComment';
import axios from 'axios';

export const PostDetail = () => {
  const { postId } = useParams(); // Obtenemos el ID de la publicación desde la URL
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get(`http://127.0.0.1:3000/posts/${postId}`)
      .then(response => {
        setPost(response.data);
        setLoading(false);
      })
      .catch(err => {
        setError('Error al cargar los detalles de la publicación');
        setLoading(false);
      });

    axios.get(`http://127.0.0.1:3000/comments/getComments/${postId}`)
      .then(response => {
        setComments(response.data);
      })
      .catch(err => {
        setError('Error al cargar los comentarios');
      });
  }, [postId]);

  if (loading) return <p>Cargando detalles...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="post-detail">
      <h1>{post.title}</h1>
      <p>{post.content}</p>
      <h3>Comentarios</h3>
      <div>
        {comments.map(comment => (
          <div key={comment._id} className="comment">
            <p><strong>{comment.name}</strong>: {comment.content}</p>
          </div>
        ))}
      </div>
      <AddComment postId={postId} />
    </div>
  );
};
