import React from 'react';
import '../styles/Navbar.css'; // Si usas un archivo CSS separado

export const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <h1 className="navbar-title">Blog de Aprendizaje</h1>
      </div>
    </nav>
  );
}
