// src/components/AddComment.jsx
import React, { useState } from 'react';
import axios from 'axios';

export const AddComment = ({ postId }) => {
  const [comment, setComment] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://127.0.0.1:3000/comments/addComment/${postId}`, {
        content: comment,
        name: name,
      });
      setSuccess(true);
      setComment('');
      setName('');
    } catch (err) {
      setError('Hubo un error al agregar el comentario.');
    }
  };

  return (
    <div className="add-comment">
      <h3>Agregar un comentario</h3>
      {error && <p className="error">{error}</p>}
      {success && <p className="success">Comentario agregado con éxito</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Tu nombre"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Escribe tu comentario"
        />
        <button type="submit">Agregar Comentario</button>
      </form>
    </div>
  );
};
