import React from 'react';
import ReactDOM from 'react-dom/client'; // Importamos ReactDOM de 'react-dom/client'
import { AppRoutes } from './routes'; // O el archivo que contiene las rutas de tu aplicación
import './styles/index.css'; // Si tienes un archivo de estilos

// Usamos createRoot para crear el contenedor de la aplicación
const root = ReactDOM.createRoot(document.getElementById('root'));

// Renderizamos la aplicación con createRoot
root.render(
  <React.StrictMode>
    <AppRoutes />
  </React.StrictMode>
);
