import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { GetPost } from './components/GetPost';
import { PostDetail } from './components/PostDetail'; // Asegúrate de importar PostDetail

export const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<GetPost />} />
        <Route path="/posts/getPostById/:postId" element={<PostDetail />} />
      </Routes>
    </Router>
  );
};
