import axios from "axios";

export const Posts = async (formData) => {
    try {
        return await axios.get("http://127.0.0.1:3000/blogAprendizaje/v1", formData)
    }catch(error){
        return{
            error: true,
            message: error.message
        }
    }
}